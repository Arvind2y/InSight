# LMS [SAMPLE]

A leave management system sending a template email to the manager within all the informations of the employee request

## Technologies
- ASP.NET C#
- MVC 5 Razor
- Javascript / jQuery
- Telerik UI
- SQL Server
